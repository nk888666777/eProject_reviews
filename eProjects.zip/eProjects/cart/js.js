function them(x){
    var tr= x.parentElement.parentElement;
    var td=tr.children;
    var msdv=td[0].innerHTML;
    var dichvu=td[1].children[0].innerHTML;
    var dongia=td[2].children[0].innerHTML;
    var magiamgia= document.getElementById("mgg").value;


    var giohang_tr=document.createElement("tr");
    var giohang_td=document.createElement("td");
    
    var giohang_td_msdv=document.createTextNode(msdv);
    giohang_td.appendChild(giohang_td_msdv)
    giohang_tr.appendChild(giohang_td);
//---------------------
    var giohang_td=document.createElement("td");
    var giohang_td_dichvu=document.createTextNode(dichvu);
    giohang_td.appendChild(giohang_td_dichvu)
    giohang_tr.appendChild(giohang_td);
//-------------------
    var giohang_td=document.createElement("td");
    var giohang_td_dongia=document.createTextNode(dongia);
    giohang_td.appendChild(giohang_td_dongia)
    giohang_tr.appendChild(giohang_td);

    var giohang_td=document.createElement("td");
    var giohang_td_nut=document.createElement("input");
    giohang_td_nut.type="button";
    giohang_td_nut.value="Xóa";
    giohang_td_nut.setAttribute("onclick", "xoa(this)")
    giohang_td.appendChild(giohang_td_nut);
    giohang_tr.appendChild(giohang_td);

    
    ////
    var giohang=document.getElementById("giohang");
    giohang.appendChild(giohang_tr);

    //-------------------------------------------

    //tinh tong don hang
tongdonhang();


}
function xoa(x){
    var tr=x.parentElement.parentElement;
    tr.remove();
}
function tongdonhang(){
    var magiamgia= document.getElementById("mgg").value;
    var giohang=document.getElementById("giohang");
    var tr = giohang.children;
    var tamtinh=o;
    for(let i=0; i<tr.length; i++){
        var td =tr[i].getElementsByTagName("td");
        var tamtinh=parseInt(td[2].innerHTML);
        tamtinh +=dongia;
        var tong=(tamtinh *(100-magiamgia))/100;

    }
    document.getElementById("tongdonhang").innerHTML=tong;

}
